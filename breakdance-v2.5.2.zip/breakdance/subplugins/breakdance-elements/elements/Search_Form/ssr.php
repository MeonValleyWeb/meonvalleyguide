<?php
$query = get_search_query();
echo $query;
