<?php
	/**
	 * @var array $propertiesData
	 */

	$args = array(
			'delimiter' => '<div class="bde-woo-breadcrumb_delimiter"></div>',
	);
?>
<?php woocommerce_breadcrumb( $args ); ?>
